import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';

import 'custom_print.dart';

class PdfViewer extends StatefulWidget {
  String url;
  PdfViewer({Key key, this.url}) : super(key: key);

  @override
  State<PdfViewer> createState() => _PdfViewerState();
}

class _PdfViewerState extends State<PdfViewer> {
  dynamic fileBytes = null;

  void getFileBytes() async {
    capsaPrint('\n\nurl call initiated');
    // http.Response response = await http.get(
    //   Uri.parse('https://storage.googleapis.com/download/storage/v1/b/fir-anchor-creditassessment.appspot.com/o/Vendor_Terms_Conditions_2.pdf?generation=1669910580228683&alt=media'),
    // );
    try {
      http.Response response = await http.get(Uri.parse(
          'https://storage.googleapis.com/getcapsa-ca-quality.appspot.com/testnew/file1?GoogleAccessId=firebase-adminsdk-ea2mz%40getcapsa-ca-quality.iam.gserviceaccount.com&Expires=1677650418&Signature=pWV8MREVP821MZFC8rJqQch%2BCdZvonWJrlCZAW%2Fx%2B1spUHsMn2jC0KEavMnwodNegjnNiatTpiD9STeAhWXv4P8wGh6vc5guB1RAepEWLwnYcRjFJzmluHF%2BbqCQoYa7jWcgZKi90OZsSV%2B4bKzuEEK97PDeiBXjPUlL8xAHKs3EA31rK96gVJjW3APvj%2B0rzajAHI63ndOxw%2FNyXohCcbm4cUESQmSVSpIh6ZSz8DbRskEK0IkPLnJcdChFilKTgI7gGCs9yAC9NKgcEZI5I382MJK6D3BMcoh2xvPhW7qSScDiYazpbjdH0obXnerPgwpvh8%2F63HPSY0FGQ66Euw%3D%3D'),
      headers: {
        "Access-Control-Allow-Origin": "*", // Required for CORS support to work
        "Access-Control-Allow-Credentials": "true", // Required for cookies, authorization headers with HTTPS
        "Access-Control-Allow-Headers": "Origin,Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,locale",
        "Access-Control-Allow-Methods": "POST, OPTIONS"
      },
      );
      capsaPrint('received response');

      fileBytes = response.bodyBytes;

      setState(() {});
    } catch (e) {
      capsaPrint('Error: $e');
    }
    // const cors = require("cors");
    // app.use(cors());
  }

  @override
  void initState() {
    super.initState();
    getFileBytes();
  }

  @override
  Widget build(BuildContext context) {
    return fileBytes == null
        ? Center(
            child: CircularProgressIndicator(),
          )
        : SfPdfViewer.memory(
            fileBytes,
          );
  }
}
