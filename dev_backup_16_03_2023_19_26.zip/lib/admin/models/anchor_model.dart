class AnchorModel {
  String name;
  String cin;
  String email;
  String pan;
  String grade;

  AnchorModel({
    this.name,
    this.cin,
    this.email,
    this.pan,
    this.grade,
  });
}
